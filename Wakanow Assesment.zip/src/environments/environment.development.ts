export const environment = {
  API_URL: 'https://reqres.in/api'
};
